## Macross Framework Docker Image

### Info

#### Dockerfile

* Base image: `macross/java-mix:jdk-8u152-mix`
* Env parameters:
1. **JAVA_DEBUG_PORT**: debug port
1. **JMX_REMOTE_PORT**: JMX port
1. **JAVA_OPTS**: Java jvm opts
1. **JAVA_JMX_OPTS**：JMX opts
1. **JAVA_DEBUG_OPTS**: debug opts
1. **JAVA_HEAP_OPTS**: Java jvm heap opts
1. **JAVA_MEM_OPTS**: mem opts
1. **LIB_DIR**: main jar path
1. **APP_CONFIG**: application config

#### wrapper.sh

Support the following type:
* **/bin/sh**: shell type
* **debug**: debug type
* **jmx**: jmx type

### Build Image

For example: Use `JAVA_DEBUG_PORT` parameter, the default value is `8009`. 

```shell
docker build -t image_name --squash --build-arg JAVA_DEBUG_PORT=9999
```

### Generate Image with Jenkins

Add the new jenkins job, this job will generator two images for beta and online env.
The jenkins job config:

```shell
source ~/.bash_profile
rm -rf BUILD_PROP
PRODUCT_API=$(GET "http://agile.baidu.com/api/agileplus/getBuildProduct?buildUrl=$BUILD_URL&moduleRevision=MODULE-NAME")
BUILD_REV=$(python -c "import json; result=json.loads('$PRODUCT_API'); print result['MODULE-NAME']['revision'];")
PRODUCT_PATH=$(python -c "import json; result=json.loads('$PRODUCT_API'); print result['MODULE-NAME']['prodPath'];")
PRODUCT_PATH_CMD=$(python -c "import json; result=json.loads('$PRODUCT_API'); print result['MODULE-NAME']['prodPathCmd'];")
IMAGE_NAME=XXXXXX
REPO_IMAGE_NAME=XXXXXX
IMAGE_ONLINE_POST_NAME=-online
IMAGE_BETA_POST_NAME=-beta
echo "BUILD_REV=${BUILD_REV}" >> BUILD_PROP
echo "PRODUCT_PATH=${PRODUCT_PATH}" >> BUILD_PROP
echo "PRODUCT_PATH_CMD=${PRODUCT_PATH_CMD}" >> BUILD_PROP
echo "IMAGE_NAME=${IMAGE_NAME}" >> BUILD_PROP
echo "REPO_IMAGE_NAME=${REPO_IMAGE_NAME}" >> BUILD_PROP
echo "IMAGE_ONLINE_POST_NAME=${IMAGE_ONLINE_POST_NAME}" >> BUILD_PROP
echo "IMAGE_BETA_POST_NAME=${IMAGE_BETA_POST_NAME}" >> BUILD_PROP

$PRODUCT_PATH_CMD
cd output
mv *-application.tar.gz application.tar.gz
mkdir -p online beta
cp application.tar.gz online/
cp application.tar.gz beta/

######### online #########
cd online
tar xzf application.tar.gz
cd config
rm -rf application.properties
rm -rf application-beta.properties
mv application-online.properties application.properties
sed -i "s/\/home\/[^/]*\/logs/\/logs/g" application.properties
echo '
manage.ssh.open: false
' >> application.properties
cd ..
rm -rf application.tar.gz
rm -rf agent/
tar czf ../application-online.tar.gz ./
mv ../application-online.tar.gz application.tar.gz
cd docker
mv * ../
cd ..
rm -rf bin/ config/ deploy/ docker/ lib/
docker build -t $IMAGE_NAME$IMAGE_ONLINE_POST_NAME:latest .
# docker tag $IMAGE_NAME$IMAGE_ONLINE_POST_NAME:latest $IMAGE_NAME$IMAGE_ONLINE_POST_NAME:$BUILD_REV
docker tag $IMAGE_NAME$IMAGE_ONLINE_POST_NAME:latest $REPO_IMAGE_NAME$IMAGE_ONLINE_POST_NAME:latest
docker push $REPO_IMAGE_NAME$IMAGE_ONLINE_POST_NAME:latest

cd ..
rm -rf online/

######### beta #########
cd beta
tar xzf application.tar.gz
cd config
rm -rf application.properties
rm -rf application-online.properties
mv application-beta.properties application.properties
sed -i "s/\/home\/[^/]*\/logs/\/logs/g" application.properties
echo '
manage.ssh.open: false
' >> application.properties
cd ..
rm -rf application.tar.gz
rm -rf agent/ 
tar czf ../application-beta.tar.gz ./
mv ../application-beta.tar.gz application.tar.gz
cd docker
mv * ../
cd ..
rm -rf bin/ config/ deploy/ docker/ lib/
docker build -t $IMAGE_NAME$IMAGE_BETA_POST_NAME:latest .
# docker tag $IMAGE_NAME$IMAGE_BETA_POST_NAME:latest $IMAGE_NAME$IMAGE_BETA_POST_NAME:$BUILD_REV
docker tag $IMAGE_NAME$IMAGE_BETA_POST_NAME:latest $REPO_IMAGE_NAME$IMAGE_BETA_POST_NAME:latest
docker push $REPO_IMAGE_NAME$IMAGE_BETA_POST_NAME:latest

cd ..
rm -rf beta/
```

### Use Image

#### /bin/sh

```shell
docker run -ti \
--rm \
--name xiaolvyun-portal-beta \
-v /home/work/workdir/data:/data \
-v /home/work/workdir/logs:/logs \
xiaolvyun/portal-beta /bin/sh
```

#### Default

```shell
docker run -d \
--net=host \
--name xiaolvyun-portal-beta \
-v /home/work/workdir/data:/data \
-v /home/work/workdir/logs:/logs \
xiaolvyun/portal-beta
```
